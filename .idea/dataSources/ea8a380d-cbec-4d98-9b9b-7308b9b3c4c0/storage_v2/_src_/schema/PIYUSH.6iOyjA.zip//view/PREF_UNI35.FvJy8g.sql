create view PREF_UNI35 as
SELECT preference1, preference2, preference3, GRE_SCORE FROM student_gre
/

